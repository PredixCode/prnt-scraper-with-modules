import requests, os
from shutil import copyfile
from concurrent.futures import ThreadPoolExecutor

path = os.listdir("C:/Users/jonas/Desktop/Code/prnt-scraper/nudes")

def main(i):

        r = requests.post("https://api.deepai.org/api/nsfw-detector",files={'image': open("C:/Users/jonas/Desktop/Code/prnt-scraper/nudes/"+str(path[i]), 'rb'),},headers={'api-key': 'e82f5b02-35ba-440d-babe-d87391ce7503'})
        x = r.json()['output']['nsfw_score']
        y = float(path[i][:-4])
        z = "C:/Users/jonas/Desktop/Code/prnt-scraper/nudes/stage2/"+str(x)+"-screenshot.png"
        print("round:",i,"| old:",round(y,2),"| new:",round(x,2))
        if x > 0.6:
            copyfile("C:/Users/jonas/Desktop/Code/prnt-scraper/nudes/"+str(path[i]), z)
            print("| destination:"+str(z))
        return 
    


with ThreadPoolExecutor() as executer:
    results = [executer.submit(main,i) for i in range(0,len(path))]