import string,time,os
from nudenet import NudeClassifier
from urllib.request import build_opener,install_opener,urlretrieve
from os import remove, listdir, path
from random import choice,randint,shuffle
from bs4 import BeautifulSoup as bs 
from concurrent.futures import ThreadPoolExecutor
from requests import get
from pytesseract import image_to_string, pytesseract
from shutil import copyfile


#---DICT---
pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
init=time.time()
a=0
unsafe,safe,t,elapsed,prob=float,float,float,float,float
url,x,link,keyword=string,string,string,string
classifier=NudeClassifier()
probs,errors,times,round_times,ips,scams,probs = [],[],[],[],[],[],[]
i = 7
scam = bool



#---FUNCTIONS---

def url_gen(url, x):
  ranlet1 = choice(string.ascii_letters)
  ranlet2 = choice(string.ascii_letters)
  rannum1 = randint(0,9)
  rannum2 = randint(0,9)
  rannum3 = randint(0,9)
  rannum4 = randint(0,9)
  x = ranlet1.lower() + ranlet2.lower() + str(rannum1) + str(rannum2) + str(rannum3) + str(rannum4)
  url ="https://prnt.sc/" + x
  return url, x

def get_vpn(ips):
    vpn_data = get('http://www.vpngate.net/api/iphone/').text.replace('\r','')
    servers = [line.split(',') for line in vpn_data.split('\n')]
    labels = servers[1]
    labels[0] = labels[0][1:]
    servers = [s for s in servers[2:] if len(s) > 1]
    for server in servers:
        ip = server[1]
        ips.append(ip)
    return ips

def get_html(link,url,head):
    try:
      headers = {"user-agent": head}
      soup = bs(get(url,headers=headers,timeout=0.75).content, "lxml")
      links = []
      for link in soup.findAll('img'):
        link = link.get('src')
        links.append(link)
        link = links[0]
      return link
    except:
      link = "bad"
      return link
    
def down_img(link,head,x):
  try:
    req = build_opener()
    req.addheaders = [('User-Agent', head)]
    install_opener(req)
    urlretrieve(link,"temp/screenshot"+str(x)+".png")
    return 
  except:
    link = "bad"
    return link

def class_nude(prob,x):
  dict = classifier.classify("temp/screenshot"+str(x)+".png")
  unsafe = dict["temp/screenshot"+str(x)+".png"]["unsafe"]
  safe = dict["temp/screenshot"+str(x)+".png"]["safe"]
  prob = unsafe/safe
  return prob

def class_scam(keyword,x):
  text = image_to_string("C:/Users/jonas/Desktop/Code/prnt-scraper/temp/screenshot"+str(x)+".png")
  keywords = ["@gmail","password","wallet","BIC","IBAN"]
  for keyword in keywords:
    if keyword in str(text):
      return keyword
    else:
      keyword = None
  return keyword

def save(x,prob,module,keyword):
    z = ""
    if module == "nudes":
      z = prob
    if module == "scams":
      z = str(x)+"-"+str(keyword)

    copyfile("temp/screenshot"+str(x)+".png", str(module)+"/"+str(z)+".png")
    message = str(module)+":"+str(module)+"/"+str(z)+".png"
    return message

def main(url,prob,probs,x,link,times,scam,scams,keyword):

  # RANDOM URL
  url, x = url_gen(url, x)

  # GET HTML:
  with open ("user_agents.txt", "r") as file:
      file_content = file.readlines()
  head = [x[:-1] for x in file_content]
  shuffle(head)
  head = head[len(head)-2]

  link = get_html(link,url,head)
  if link=="bad":
    return int(404)
  

  # DOWNLOAD IMAGE:
  link = down_img(link,head,x)
  if link=="bad":
    return int(405)

  message = None

  # CLASSIFY NUDITY:
  module = "nudes"
  prob = class_nude(prob,x)
  probs.append(prob)
  
  if prob > 3.7:
    message = save(x,prob,module,keyword)


  # CLASSIFY SCAMMABLE:
  module = "scams"
  keyword = class_scam(keyword,x)
  if keyword != None:
    message = save(x,prob,module,keyword)
    scams.append(1)    
  
  times.append(1)

  return message
    

     
# ---MAIN LOOP---
#ips = get_vpn(ips)
#print(ips)
while True:
  start = time.time()
  with ThreadPoolExecutor() as executer:
    results = [executer.submit(main,url,prob,probs,x,link,times,scam,scams,keyword) for _ in range(i)]
    for result in results:
      if type(result.result()) == int:
        errors.append(result.result())
      if type(result.result()) == str:
        print(result.result())

  if len(probs) > 0:
    high_prob = round(max(probs),2)
  else:
    high_prob = "no images to classify"

  end = time.time()
  round_times.append(end-start)
  print("high(nude)score:",high_prob,"| scams:",str(len(scams))+"/"+str(i),"| time:",str(round((sum(round_times)/len(round_times))/i,3))+"s","| downloaded:",len(times),"| errors:",str(len(errors))+"x")

  if len(os.listdir("C:/Users/jonas/Desktop/Code/prnt-scraper/temp")) > i*20:
    dir = "C:/Users/jonas/Desktop/Code/prnt-scraper/temp"
    for f in listdir(dir):
      remove(path.join(dir, f))


  probs.clear()
  scams.clear()
  errors.clear()